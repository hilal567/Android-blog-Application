package com.example.photoblog;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toolbar;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    private Toolbar mainToolbar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mainToolbar = (Toolbar)findViewById(R.id.main_toolbar);
       setSupportActionBar(mainToolbar);

       getActionBar().setTitle("Photo Blog");


    }
    //implement callback in case the app has been minimised
    @Override
    protected void onStart (){
        super.onStart();

        //method to check if the user is logged in...if not take the user to the login page.
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser == null) {
            //take the user to the login page
            Intent loginIntent = new Intent(MainActivity.this,Login_Activity.class);
            startActivity(loginIntent);

            //make sure the user doesn't come back using the back button once logged in.
            finish();

        } else {
            // No user is signed in
        }

    }
}
